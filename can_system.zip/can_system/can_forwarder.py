import websockets
import asyncio
import can

async def send_can_data(websocket):
    bus = can.interface.Bus(channel='can0',bustype='socketcan')
    while True:
        msg = bus.recv(1)
        if msg:
            data={
                    "id":hex(msg.arbitration_id),
                    "data":list(msg.data)
            }
            await websocket.send(str(data))

async def main():
    async with websockets.serve(send_can_data,"0.0.0.0",8765):
        await asyncio.Future()

if __name__ == "__main__":
    asyncio.run(main())
