#!/bin/bash

CAN_INTERFACE="can0"
BITRATE="500000"
USERNAME=$(nvidia)

sudo apt update && sudo apt upgrade -y
sudo apt install -y can-utils python3 python3-pip git net-tools

sudo modprobe can
sudo ip link set dev $CAN_INTERFACE down 2>/dev/null
sudo ip link set $CAN_INTERFACE type can bitrate ￥BITRATE
sudo ip link set up $CAN_INTERFACE

sudo cp can_forwarder.py /usr/local/bin/
sudo cp can_forwarder.service /etc/systemd/system/
sudo cp 80-can.rules /etc/udev/rules.d/

sudo groupadd canbus 2>/dev/null
sudo usermod -aG canbus $USERNAME
sudo udevadm control --reload
sudo systemctl daemon-reload
sudo systemctl enable can_forwarder.service
sudo systemctl start can_forwarder.service


sudo ufw allow 8765/tcp
sudo ufw reload

echo "部署完成！重启后生效。"
